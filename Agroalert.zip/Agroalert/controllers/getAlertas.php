<?php
require_once '../config/conexion.php';

header('Content-Type: application/json');

$result = $conn->query("SELECT * FROM alertas ORDER BY id_alerta DESC LIMIT 20");

$alertas = [];
while ($row = $result->fetch_assoc()) {
    $alertas[] = $row;
}

echo json_encode($alertas);
