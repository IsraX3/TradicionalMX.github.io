<?php
session_start();
require_once '../config/conexion.php';
require_once '../models/usuario.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error']);
    exit;
}

$nombre = trim($_POST['nombre'] ?? '');
$correo = trim($_POST['correo'] ?? '');
$password = trim($_POST['password'] ?? '');
$confirmar = trim($_POST['confirmar'] ?? '');

$correoActual = $_SESSION['usuario'] ?? null;

if (!$correoActual) {
    echo json_encode(['status' => 'error']);
    exit;
}

if ($password !== $confirmar) {
    echo json_encode(['status' => 'error']);
    exit;
}

$usuarioModel = new Usuario($conn);
$resultado = $usuarioModel->actualizarUsuario($correoActual, $nombre, $correo, $password);

if ($resultado) {
    $_SESSION['usuario'] = $correo;
    $_SESSION['usuario_nombre'] = $nombre;
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error']);
}
?>
