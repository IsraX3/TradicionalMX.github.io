<?php
require_once '../config/conexion.php';
require_once '../models/registroUsuario.php';

$registro = new RegistroUsuario($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $correo = trim($_POST['correo']);
    $password = trim($_POST['password']);
    $tipo_usuario = $_POST['tipo_usuario'] ?? "normal";

    // Validar campos vacíos
    if (empty($nombre) || empty($correo) || empty($password)) {
        header("Location: ../views/register.php?error=" . urlencode("Todos los campos son obligatorios"));
        exit;
    }

    // Validar si el correo ya existe
    if ($registro->existeCorreo($correo)) {
        header("Location: ../views/register.php?error=" . urlencode("El correo ya está registrado"));
        exit;
    }

    // Intentar registrar
    if ($registro->registrar($nombre, $correo, $password, $tipo_usuario)) {
        header("Location: ../views/login.php?success=" . urlencode("Usuario registrado correctamente"));
    } else {
        header("Location: ../views/register.php?error=" . urlencode("Error al registrar usuario"));
    }
}
?>
