<?php
session_start();

class AvatarController {
    private $baseUrl;

    public function __construct() {
        // Detecta automáticamente el host y protocolo
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";

        // Construye la URL dinámica
        $this->baseUrl = $protocol . $host . "/web/Agroalert/public/avatars/";
    }

    // Retorna todos los avatares disponibles
    public function getAvatars() {
        $avatars = [
            ["id" => 1, "name" => "Avatar Hombre 1", "url" => $this->baseUrl . "Avatar_hombre_1.png"],
            ["id" => 2, "name" => "Avatar Hombre 2", "url" => $this->baseUrl . "Avatar_hombre_2.png"],
            ["id" => 3, "name" => "Avatar Hombre 3", "url" => $this->baseUrl . "Avatar_hombre_3.png"],
            ["id" => 4, "name" => "Avatar Mujer 1", "url" => $this->baseUrl . "Avatar_mujer_1.png"],
            ["id" => 5, "name" => "Avatar Mujer 2", "url" => $this->baseUrl . "Avatar_mujer_2.png"],
            ["id" => 6, "name" => "Avatar Mujer 3", "url" => $this->baseUrl . "Avatar_mujer_3.png"],
            ["id" => 7, "name" => "Avatar Mujer 4", "url" => $this->baseUrl . "Avatar_mujer_4.png"],
            ["id" => 8, "name" => "Avatar Mujer 5", "url" => $this->baseUrl . "Avatar_mujer_5.png"]
        ];

        header('Content-Type: application/json');
        echo json_encode($avatars);
    }

    // Guarda el avatar seleccionado en la sesión
    public function setAvatar() {
        $data = json_decode(file_get_contents("php://input"), true);
        header('Content-Type: application/json');

        if (!empty($data['url'])) {
            $_SESSION['avatar'] = $data['url'];
            echo json_encode(['success' => true, 'avatar' => $_SESSION['avatar']]);
        } else {
            echo json_encode(['success' => false, 'error' => 'URL de avatar no recibida']);
        }
    }
}

// ---------------------------
// Determinar la acción según el método
// ---------------------------
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    $controller = new AvatarController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $controller->setAvatar();
    } else {
        $controller->getAvatars();
    }
}
?>
