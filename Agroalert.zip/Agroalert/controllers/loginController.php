<?php
session_start();
require_once '../config/conexion.php';
require_once '../models/usuario.php';

$usuario = new Usuario($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'];
    $password = $_POST['password'];

    $login = $usuario->login($correo, $password);

    if ($login) {
        // Guardamos más información en la sesión
        $_SESSION['usuario_id'] = $login['id_usuario'];
        $_SESSION['usuario_nombre'] = $login['nombre'];
        $_SESSION['usuario_correo'] = $login['correo'];
        $_SESSION['tipo_usuario'] = $login['tipo_usuario'];

        // Esto mantiene compatibilidad con tu código viejo
        $_SESSION['usuario'] = $login['nombre']; 

        // Redirección según el tipo
        if ($login['tipo_usuario'] === 'root') {
            header("Location: ../views/adminDashboard.php");
        } else {
            header("Location: ../views/dashboard.php");
        }
        exit;
    } else {
        $_SESSION['login_error'] = "Correo o contraseña incorrectos.";
        header("Location: ../views/login.php");
        exit;
    }
}
?>
