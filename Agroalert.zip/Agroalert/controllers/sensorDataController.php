<?php
require __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/conexion.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

// ========================
// CONFIGURACIÓN DEL BROKER
// ========================
$server   = '192.168.1.72'; // IP de la Raspberry Pi
$port     = 1883;
$clientId = 'php-consumer';

$connectionSettings = (new ConnectionSettings)
    ->setKeepAliveInterval(60);

$mqtt = new MqttClient($server, $port, $clientId);
$mqtt->connect($connectionSettings);

echo "Conectado al broker MQTT en $server:$port\n";

// =============================
// SUSCRIPCIÓN AL TOPIC DE DATOS
// =============================
$mqtt->subscribe('agroalert/sensores/ambiente', function (string $topic, string $message) use ($conn) {
    $data = json_decode($message, true);

    echo "Mensaje recibido: $message\n";

    if ($data && isset($data['id_sensor'], $data['temperatura'], $data['humedad'], $data['luz'], $data['ts'])) {
        $stmt = $conn->prepare("
            INSERT INTO lectura_sensor (id_sensor, temperatura, humedad, luz, fecha_hora)
            VALUES (?, ?, ?, ?, FROM_UNIXTIME(?))
        ");
        $stmt->bind_param("iddds", $data['id_sensor'], $data['temperatura'], $data['humedad'], $data['luz'], $data['ts']);

        if ($stmt->execute()) {
            echo "Dato insertado correctamente\n";

            // ======================
            // ANÁLISIS DE CONDICIONES
            // ======================
            $temp = $data['temperatura'];
            $hum  = $data['humedad'];

            // --- Condiciones para MOSCA BLANCA ---
             if ($temp > 25 && $temp < 35 && $hum > 60 && $hum < 85) {
                $mensaje = "⚠️ Condiciones favorables para la MOSCA BLANCA detectadas (T={$temp}°C, H={$hum}%)";
                echo "$mensaje\n";
                $alerta = $conn->prepare("INSERT INTO alertas (mensaje, fecha_hora) VALUES (?, NOW())");
                $alerta->bind_param("s", $mensaje);
                $alerta->execute();
                $alerta->close();
            }

            // --- Condiciones para CHILE HABANERO ---
            if ($temp >= 20 && $temp <= 30 && $hum >= 50 && $hum <= 70) {
                $mensaje = "🌿 Condiciones óptimas para el CHILE HABANERO (T={$temp}s°C, H={$hum}%)";
                echo "$mensaje\n";
                $alerta = $conn->prepare("INSERT INTO alertas (mensaje, fecha_hora) VALUES (?, NOW())");
                $alerta->bind_param("s", $mensaje);
                $alerta->execute();
                $alerta->close();
            }


            // ===============================
            // LIMPIEZA AUTOMÁTICA DE REGISTROS
            // ===============================
            $limpiar = "
                DELETE FROM lectura_sensor 
                WHERE id_lectura NOT IN (
                    SELECT id_lectura FROM (
                        SELECT id_lectura FROM lectura_sensor ORDER BY id_lectura DESC LIMIT 30
                    ) AS ultimos
                );
            ";
            $conn->query($limpiar);
            echo "Limpieza automática: solo se conservan los últimos 30 registros.\n";
        } else {
            echo "Error al insertar: " . $stmt->error . "\n";
        }

        $stmt->close();
    } else {
        echo "JSON inválido o incompleto: $message\n";
    }
}, 0);

// Mantener el proceso escuchando indefinidamente
$mqtt->loop(true);
