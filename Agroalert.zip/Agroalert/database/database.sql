CREATE DATABASE mi_dashboard;
USE mi_dashboard;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Usuario de prueba
INSERT INTO usuarios (email, password) VALUES 
('admin@correo.com', '$2y$10$9fUURBtb9E4T.hzYkN5fPOhU1k6hZ5l4bf4a1EByO70Eqf/pTLQbW');
-- Contraseña: admin123
