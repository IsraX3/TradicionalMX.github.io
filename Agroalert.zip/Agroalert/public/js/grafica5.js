// Gráfica 5 Infestación vs Umbral 
var ctxRiesgo = document.getElementById("chartUmbralRiesgo").getContext("2d");

var gradientInfestacion = ctxRiesgo.createLinearGradient(0, 0, 0, 300);
gradientInfestacion.addColorStop(0, 'rgba(33, 150, 243, 0.5)'); 
gradientInfestacion.addColorStop(1, 'rgba(33, 150, 243, 0.0)');

new Chart(ctxRiesgo, {
  type: 'line',
  data: {
    labels: ['Semana 1', 'Semana 2', 'Semana 3', 'Semana 4'],
    datasets: [
      {
        label: 'Nivel de Infestación (Moscas)',
        data: [12, 18, 25, 21, 30],
        backgroundColor: gradientInfestacion,
        borderColor: 'rgba(33, 150, 243, 1)',
        borderWidth: 3,
        pointBackgroundColor: 'rgba(33, 150, 243, 1)',
        fill: true,
        tension: 0.4
      },
      {
        label: 'Umbral de Riesgo',
        data: [20, 20, 20, 20, 20],
        borderColor: '#FF5252', 
        borderDash: [5, 5],
        borderWidth: 3,
        pointRadius: 0,
        fill: false
      }
    ]
  },
  options: {
    responsive: true,
    plugins: {
      legend: { labels: { color: '#555' } }
    },
    scales: {
      x: { ticks: { color: '#888' } },
      y: { ticks: { color: '#888' } }
    }
  }
});


