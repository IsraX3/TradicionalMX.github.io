// TABLA 1 ZONAS CRÍTICAS
const zonas = [
  { zona: "Sector A", moscas: 22, estado: "Alto" },
  { zona: "Sector B", moscas: 10, estado: "Bajo" },
  { zona: "Sector C", moscas: 15, estado: "Moderado" },
  { zona: "Sector D", moscas: 30, estado: "Crítico" }
];

const tablaZonas = document.getElementById("tablaZonas");

if (tablaZonas) {
  zonas.forEach(z => {
    const row = tablaZonas.insertRow();
    row.innerHTML = `
      <td>${z.zona}</td>
      <td>${z.moscas}</td>
      <td>${z.estado}</td>
      
    `;
  });
}

