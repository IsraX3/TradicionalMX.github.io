<?php
class Usuario {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    // Método de login
    public function login($correo, $password) {
        $sql = "SELECT * FROM usuario WHERE correo = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Verificar contraseña encriptada
            if (password_verify($password, $user['contraseña'])) {
                return $user; // Devuelve todos los datos del usuario
            }
        }
        return false; // Login fallido
    }

    // ✅ Método para actualizar usuario (debe estar dentro de la clase)
    public function actualizarUsuario($correoActual, $nuevoNombre, $nuevoCorreo, $nuevoPassword = null) {
        if ($nuevoPassword) {
            $hash = password_hash($nuevoPassword, PASSWORD_DEFAULT);
            $sql = "UPDATE usuario SET nombre = ?, correo = ?, contraseña = ? WHERE correo = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("ssss", $nuevoNombre, $nuevoCorreo, $hash, $correoActual);
        } else {
            $sql = "UPDATE usuario SET nombre = ?, correo = ? WHERE correo = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("sss", $nuevoNombre, $nuevoCorreo, $correoActual);
        }

        return $stmt->execute();
    }
}
?>
