<?php
class RegistroUsuario {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

 public function existeCorreo($correo) {
    $sql = "SELECT id_usuario FROM usuario WHERE correo = ?";
    $stmt = $this->conn->prepare($sql);

    if (!$stmt) {
        die("Error en la consulta: " . $this->conn->error);
    }

    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $result = $stmt->get_result();

    return $result->num_rows > 0;
}

public function registrar($nombre, $correo, $password, $tipo_usuario = "normal") {
    // Encriptar la contraseña
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO usuario (nombre, correo, contraseña, tipo_usuario) VALUES (?, ?, ?, ?)";
    $stmt = $this->conn->prepare($sql);

    if (!$stmt) {
        die("Error en la consulta: " . $this->conn->error);
    }

    $stmt->bind_param("ssss", $nombre, $correo, $hash, $tipo_usuario);
    return $stmt->execute();
}



}
?>
