<?php
session_start();
if (!isset($_SESSION['usuario'])) {
   header("Location: ../public/index.php");
    exit();
}
?>


<?php
// Incluir modal
include __DIR__ . '/components/logoutModal.php';
?>

<?php include __DIR__ . '/components/Temperatura_humedad_modal.php'; ?>

<?php include __DIR__ . '/components/Filtrar_modal.php'; ?>

<?php include __DIR__ . '/../views/components/Avatar_modal.php'; ?>

<?php include __DIR__ . '/components/Update_datos.php'; ?>


<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel de Monitoreo</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <!-- CSS externo -->
  <link rel="stylesheet" href="../public/css/panel.css">
  <link rel="stylesheet" href="../public/css/modalavatar.css">
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar d-flex flex-column">
    <h3 class="text-center mb-4">🌱 AgroAlert</h3>
   <a href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
  <i class="bi bi-power"></i> Cerrar Sesión</a>
<a href="#" data-bs-toggle="modal" data-bs-target="#filtrarModal">
  <i class="bi bi-lightning"></i> Búsqueda
</a>

    <a href="#"><i class="bi bi-gear"></i> Configuración</a>
  </div>

  <!-- Main content -->
<div class="content">
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm rounded mb-4 border">
  <div class="container-fluid">
    <span class="navbar-brand fw-bold text-success">
      <i class="bi bi-seedling me-2"></i> Panel de monitoreo
    </span>

    <div class="d-flex align-items-center">
      <!-- Nombre de usuario -->
      <span class="me-3 text-muted">Bienvenido, 
  <strong><?php echo htmlspecialchars($_SESSION['usuario_nombre'] ?? 'Usuario'); ?></strong>
</span>

      </span>

      <!-- Dropdown de usuario -->
      <div class="dropdown">
        <a class="btn btn-outline-success dropdown-toggle d-flex align-items-center" 
   href="#" role="button" id="userMenu" data-bs-toggle="dropdown" aria-expanded="false">
  <img id="avatarActual" 
       src="http://localhost/web/Agroalert/public/avatars/Avatar_hombre_1.png" 
       alt="Avatar" 
       class="rounded-circle me-2 border border-success"
       style="width:40px; height:40px; object-fit:cover;">
</a>

        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="userMenu">
  <li>
    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modalAvatar">
      <i class="bi bi-image me-2"></i>Cambiar avatar
    </a>
  </li>
 <li>
  <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modalActualizarUsuario">
    <i class="bi bi-gear me-2"></i>Actualizar mis datos
  </a>
</li>

  <li><a class="dropdown-item" href="#"><i class="bi bi-bar-chart-line me-2"></i>Borrar mis datos</a></li>
  <li><hr class="dropdown-divider"></li>
</ul>

      </div>
    </div>
  </div>
</nav>

  <!-- Cards -->
<div class="row g-4">
  <!-- Card combinado Temperatura + Humedad -->
  <div class="col-12 col-lg-6">
    <div class="card p-3 d-flex flex-column flex-md-row align-items-center justify-content-between shadow rounded-4">
      
      <!-- Temperatura -->
      <div class="d-flex align-items-center mb-3 mb-md-0">
        <div class="icon-circle me-3"><i class="bi bi-thermometer-half"></i></div>
        <div>
          <h5>Temperatura</h5>
          <h3 id="temp">26°C</h3>
        </div>
      </div>

      <!-- Separador visual -->
      <div class="d-none d-md-block mx-3 border-start" style="height:50px;"></div>

      <!-- Humedad -->
      <div class="d-flex align-items-center mb-3 mb-md-0">
        <div class="icon-circle me-3"><i class="bi bi-droplet"></i></div>
        <div>
          <h5>Humedad</h5>
          <h3 id="hum">55%</h3>
        </div>
      </div>

      <!-- Icono de ojo para abrir modal -->
      <button class="btn btn-outline-primary mt-3 mt-md-0 ms-md-3" data-bs-toggle="modal" data-bs-target="#tempHumModal">
        <i class="bi bi-eye"></i>
      </button>
    </div>
  </div>

  <!-- Card Luz -->
<div class="col-12 col-md-6 col-lg-3">
  <div id="estado-raspberry" class="card p-3 shadow rounded-4 border text-center">
    <div class="d-flex flex-column align-items-center">
      <i id="icono-raspberry" class="bi bi-circle text-secondary fs-1 mb-2"></i>
      <h5>Raspberry / Sensor</h5>
      <h6 id="texto-raspberry" class="text-muted">Esperando datos...</h6>
    </div>
  </div>
</div>

<div class="col-lg-6 col-md-12 mb-4">
  <div class="card shadow-lg border-0 rounded-4" style="background: linear-gradient(180deg, #e9f7ef, #d4efdf);">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="card-title fw-bold text-success mb-0">
          <i class="bi bi-bug-fill"></i> Detección de Mosca Blanca
        </h5>
        <button class="btn btn-outline-success btn-sm" onclick="actualizarDeteccion()">
          <i class="bi bi-arrow-repeat"></i> Actualizar
        </button>
      </div>

      <div class="text-center mb-3">
        <i class="bi bi-eye-fill display-4 text-success"></i>
        <p class="mt-2 mb-0 fw-semibold text-dark">
          <span id="ultimaClase">Cargando...</span>
        </p>
        <small class="text-muted">
          Confianza: <span id="ultimaConfianza">--%</span>
        </small><br>
        <small class="text-muted">
          Última detección: <span id="ultimaFecha">--</span>
        </small>
      </div>

      <hr>

      <div class="d-flex justify-content-between align-items-center">
        <span class="fw-bold text-secondary">Total detectadas (últimos 10 min):</span>
        <span class="badge bg-success fs-6" id="conteo10min">--</span>
      </div>

      <div class="mt-3 text-center">
        <small class="text-muted">Datos actualizados automáticamente cada 60s</small>
      </div>
    </div>
  </div>
</div>

<!-- Card Alertas -->
<div class="col-12 col-md-6 col-lg-3">
  <div class="card p-3 shadow rounded-4 h-100 d-flex flex-column justify-content-between">
    <!-- Header -->
    <div class="d-flex align-items-center mb-3">
      <div class="icon-circle me-3 bg-warning text-dark">
        <i class="fa-solid fa-bell fa-shake"></i>
      </div>
      <h5 class="mb-0">Alertas</h5>
    </div>

    

    <!-- Body con scroll -->
    <div class="flex-grow-1 overflow-auto" style="max-height:150px;">
      <?php
        require_once '../config/conexion.php';
        $alertas = $conn->query("SELECT * FROM alertas ORDER BY id_alerta DESC LIMIT 6");

        if ($alertas && $alertas->num_rows > 0) {
          while ($a = $alertas->fetch_assoc()) {
            $mensaje = htmlspecialchars($a['mensaje']);
            $fecha = date('d/m/Y H:i', strtotime($a['fecha_hora']));

            if (stripos($mensaje, 'MOSCA BLANCA') !== false) {
              $icono = 'fa-solid fa-bug';
              $color = 'danger';
              $bg = 'bg-danger-subtle';
            } elseif (stripos($mensaje, 'CHILE HABANERO') !== false) {
              $icono = 'fa-solid fa-pepper-hot';
              $color = 'success';
              $bg = 'bg-success-subtle';
            } else {
              $icono = 'fa-solid fa-circle-info';
              $color = 'secondary';
              $bg = 'bg-secondary-subtle';
            }

            echo "
              <div class='alert alert-$color d-flex align-items-start shadow-sm rounded-4 $bg border-0 mb-2 p-2'>
                <div class='me-2'>
                  <i class='$icono fa-lg text-$color'></i>
                </div>
                <div class='flex-grow-1'>
                  <strong class='d-block'>$mensaje</strong>
                  <small class='text-muted'>
                    <i class='fa-regular fa-clock me-1'></i> $fecha
                  </small>
                </div>
              </div>
            ";
          }
        } else {
          echo "
            <div class='alert alert-secondary text-center rounded-4 p-2'>
              <i class='fa-regular fa-circle-check fa-lg mb-1'></i><br>
              No hay alertas recientes
            </div>
          ";
        }
      ?>
    </div>

    <!-- Footer -->
    <div class="card-footer text-center bg-white border-0 py-1">
      <small class="text-muted">
        <i class="fa-solid fa-rotate me-1"></i> Actualización automática
      </small>
    </div>
  </div>
</div>



    <!-- Progress bars -->
    <div class="row mt-5">
      <div class="col-12 col-md-6 mb-3">
        <h5>Humedad del Suelo</h5>
        <div class="progress" style="height: 25px;">
          <div id="soilProgress" class="progress-bar bg-success" role="progressbar" style="width: 0%">0%</div>
        </div>
      </div>
      <div class="col-12 col-md-6 mb-3">
        <h5>Luz Recibida</h5>
        <div class="progress" style="height: 25px;">
          <div id="lightProgress" class="progress-bar bg-warning" role="progressbar" style="width: 0%">0%</div>
        </div>
      </div>
    </div>

  </div>


  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <!-- script de modal -->
  <script src="components/Temperatura_humedad_modal.php"></script>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Animación de barras
    function animateProgress(id, value) {
      const bar = document.getElementById(id);
      let width = 0;
      const interval = setInterval(() => {
        if (width >= value) clearInterval(interval);
        else {
          width++;
          bar.style.width = width + '%';
          bar.textContent = width + '%';
        }
      }, 20);
    }

    window.onload = () => {
      animateProgress('soilProgress', 55);
      animateProgress('lightProgress', 80);
    };
  </script>



<script src="https://unpkg.com/mqtt/dist/mqtt.min.js"></script>
<script>
  // IP Raspberry
  const brokerUrl = 'ws://192.168.1.72:9001';
  const client = mqtt.connect(brokerUrl);

  const estadoCard = document.getElementById('estado-raspberry');
  const icono = document.getElementById('icono-raspberry');
  const texto = document.getElementById('texto-raspberry');

  client.on('connect', function() {
    console.log("Conectado al broker MQTT desde la web");
    client.subscribe("estado/raspberrypi");
  });

  client.on('message', function(topic, message) {
    const estado = message.toString();
    console.log("Estado recibido:", estado);
    texto.textContent = estado;

    // Cambiar icono y color
    if (estado.includes("Sensor activo")) {
      icono.className = "bi bi-cpu text-success fs-1 mb-2";
      estadoCard.classList.add('border-success');
      estadoCard.classList.remove('border-danger', 'border-warning');
    } else if (estado.includes("Sensor detenido")) {
      icono.className = "bi bi-exclamation-triangle text-warning fs-1 mb-2";
      estadoCard.classList.add('border-warning');
      estadoCard.classList.remove('border-success', 'border-danger');
    } else if (estado.includes("conectada")) {
      icono.className = "bi bi-wifi text-primary fs-1 mb-2";
      estadoCard.classList.add('border-primary');
      estadoCard.classList.remove('border-success', 'border-warning', 'border-danger');
    } else {
      icono.className = "bi bi-x-circle text-danger fs-1 mb-2";
      estadoCard.classList.add('border-danger');
      estadoCard.classList.remove('border-success', 'border-warning');
    }
  });

  client.on('error', function(err) {
    texto.textContent = "Error de conexión MQTT";
    icono.className = "bi bi-x-circle text-danger fs-1 mb-2";
    estadoCard.classList.add('border-danger');
  });
</script>


<script src="components/Avatar_modal.php"></script>
<script src="components/Update_datos"></script>
</body>
</html>
