<?php
require_once __DIR__ . '/../config/conexion.php';

header('Content-Type: application/json');

// Obtener las últimas 20 lecturas
$query = "SELECT temperatura, humedad, fecha_hora 
          FROM lectura_sensor 
          WHERE id_sensor = 1
          ORDER BY fecha_hora DESC 
          LIMIT 20";

$result = $conn->query($query);
$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode(array_reverse($data)); // invertir para mostrar de antiguo a reciente
