<!-- web\Agroalert\views\components\logoutModal.php -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="logoutModalLabel">
          <i class="bi bi-exclamation-triangle-fill"></i> Confirmación
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center">
        <p>¿Estás seguro de que deseas cerrar sesión?</p>
      </div>
      <div class="modal-footer justify-content-center">
        <a href="../controllers/logout.php" class="btn btn-danger">
          <i class="bi bi-power"></i> Sí, cerrar sesión
        </a>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
          <i class="bi bi-x-circle"></i> Cancelar
        </button>
      </div>
    </div>
  </div>
</div>
