<div class="modal fade" id="modalAvatar" tabindex="-1" aria-labelledby="modalAvatarLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content shadow-lg border-0">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="modalAvatarLabel">
          <i class="bi bi-person-bounding-box me-2"></i>Selecciona tu avatar
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body bg-light">
        <div id="avatar-grid" class="row g-4 justify-content-center"></div>
      </div>
    </div>
  </div>
</div>





<script>
document.addEventListener("DOMContentLoaded", () => {
  const grid = document.getElementById("avatar-grid");

  // Cargar avatares
  fetch("http://localhost/web/Agroalert/controllers/AvatarController.php")
    .then(res => {
      if (!res.ok) throw new Error("Error al obtener avatares");
      return res.json();
    })
    .then(data => {
      const avatarGuardado = localStorage.getItem("avatarSeleccionado");

      data.forEach(avatar => {
        const col = document.createElement("div");
        col.className = "col-4 col-md-3 text-center mb-3";

        const container = document.createElement("div");
        container.className = "avatar-container shadow-sm";
        container.style = `
          width: 120px;
          height: 120px;
          border-radius: 50%;
          overflow: hidden;
          margin: 0 auto;
          border: 3px solid #198754;
          display: flex;
          align-items: center;
          justify-content: center;
          background: white;
          transition: transform 0.3s, box-shadow 0.3s;
          cursor: pointer;
        `;

        const img = document.createElement("img");
        img.src = avatar.url;
        img.alt = avatar.name;
        img.style = "width: 100%; height: 100%; object-fit: cover;";

        // Si es el avatar guardado, marcarlo visualmente
        if (avatarGuardado === avatar.url) {
          container.style.transform = "scale(1.08)";
          container.style.boxShadow = "0 0 12px rgba(0, 0, 0, 0.2)";
        }

        // Evento de selección
        container.onclick = () => seleccionarAvatar(avatar.url, container);

        container.appendChild(img);
        col.appendChild(container);
        grid.appendChild(col);
      });
    })
    .catch(err => console.error("Error:", err));

  // Si hay avatar guardado, mostrarlo en el navbar
  const avatarGuardado = localStorage.getItem("avatarSeleccionado");
  if (avatarGuardado) {
    const avatarImg = document.getElementById("avatarActual");
    if (avatarImg) avatarImg.src = avatarGuardado;
  }
});

function seleccionarAvatar(url, container) {
  // Actualizar el avatar en el navbar
  const avatarImg = document.getElementById("avatarActual");
  if (avatarImg) avatarImg.src = url;

  // Guardar selección
  localStorage.setItem("avatarSeleccionado", url);

  // Quitar selección previa visual
  document.querySelectorAll(".avatar-container").forEach(c => {
    c.style.transform = "scale(1)";
    c.style.boxShadow = "none";
  });

  // Marcar nuevo seleccionado
  container.style.transform = "scale(1.08)";
  container.style.boxShadow = "0 0 12px rgba(0,0,0,0.2)";

  // Cerrar modal
  const modal = bootstrap.Modal.getInstance(document.getElementById('modalAvatar'));
  if (modal) modal.hide();
}
</script>
