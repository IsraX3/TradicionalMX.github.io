<!-- Modal Filtrar -->
<div class="modal fade" id="filtrarModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <!-- Header verde -->
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title">Filtrar Datos</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <select id="tipoBusqueda" class="form-select mb-3">
          <option value="alertas">Alertas</option>
          <option value="sensor">Sensor (Temp/Humedad)</option>
        </select>
        <select id="orden" class="form-select mb-3">
          <option value="desc">Más nuevo primero</option>
          <option value="asc">Más antiguo primero</option>
        </select>

        <!-- Solo Últimos 30 -->
        <select id="filtro" class="form-select mb-3">
          <option value="ultimos30">Últimos 20 registros</option>
        </select>
        <input type="text" id="textoFiltro" class="form-control mb-3" placeholder="Escribe algo...">

        <!-- Botón verde -->
        <button id="btnFiltrar" class="btn btn-success w-100">Filtrar</button>

        <div id="infoResultados" class="mt-3"></div>
        <div id="resultadosBusqueda" class="mt-3"></div>

        <!-- Botón PDF ya es verde -->
        <button id="btnPDF" class="btn btn-success mt-2" style="display:none;">
          <i class="bi bi-file-earmark-pdf"></i> Descargar PDF
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Script -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script>
document.getElementById('btnFiltrar').addEventListener('click', async () => {
  const tipo = document.getElementById('tipoBusqueda').value;
  const texto = document.getElementById('textoFiltro').value.trim();
  const orden = document.getElementById('orden')?.value || 'desc'; // Obtener el valor del select de orden

  let url = '';
  if(tipo === 'alertas'){
    url = '../controllers/getAlertas.php';
  } else if(tipo === 'sensor'){
    url = 'getLecturas.php';
  }

  try {
    const res = await fetch(url);
    const data = await res.json();
    const contenedor = document.getElementById('resultadosBusqueda');
    contenedor.innerHTML = '';

    // Ordenar datos según opción
    const datosOrdenados = data.sort((a, b) => {
      const fechaA = new Date(a.fecha_hora);
      const fechaB = new Date(b.fecha_hora);
      return orden === 'asc' ? fechaA - fechaB : fechaB - fechaA;
    });

    // Tomar los últimos 30 registros después de ordenar
    const ultimos30 = datosOrdenados.slice(0, 20);

    // Función para resaltar palabra clave
    const resaltar = (str, palabra) => {
      if(!palabra) return str;
      const regex = new RegExp(`(${palabra})`, 'gi');
      return str.replace(regex, `<span class="bg-warning text-dark px-1 rounded">$1</span>`);
    };

    let encontrados = 0;
    const resultadosFiltrados = [];

    if(tipo === 'alertas'){
      ultimos30.forEach(a => {
        if(!texto || a.mensaje.toLowerCase().includes(texto.toLowerCase())) {
          encontrados++;
          resultadosFiltrados.push(a);
          let icono = 'fa-solid fa-circle-info';
          let color = 'secondary';
          if(a.mensaje.includes('MOSCA BLANCA')){
            icono = 'fa-solid fa-bug';
            color = 'danger';
          } else if(a.mensaje.includes('CHILE HABANERO')){
            icono = 'fa-solid fa-pepper-hot';
            color = 'success';
          }
          contenedor.innerHTML += `
            <div class="alert alert-${color} d-flex align-items-start mb-2">
              <i class="${icono} me-2"></i>
              <div>${resaltar(a.mensaje, texto)}<br>
              <small>${a.fecha_hora}</small></div>
            </div>`;
        }
      });
    } else if(tipo === 'sensor'){
      ultimos30.forEach(s => {
        const tempStr = s.temperatura.toString();
        const humStr = s.humedad.toString();
        if(!texto || tempStr.includes(texto) || humStr.includes(texto)){
          encontrados++;
          resultadosFiltrados.push(s);
          contenedor.innerHTML += `
            <div class="card mb-2 p-2">
              <strong>Temp:</strong> ${resaltar(tempStr, texto)}°C
              <strong>Humedad:</strong> ${resaltar(humStr, texto)}%
              <small class="d-block">${s.fecha_hora}</small>
            </div>`;
        }
      });
    }

    // Mostrar cantidad de resultados
    const infoResultados = document.getElementById('infoResultados');
    infoResultados.innerHTML = `Se encontraron <strong>${encontrados}</strong> resultados${texto ? ` para "<strong>${texto}</strong>"` : ''}.`;

    // Botón de descargar PDF
const btnPDF = document.getElementById('btnPDF');
if(encontrados > 0){
  btnPDF.style.display = 'inline-block';
  btnPDF.onclick = () => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    doc.setFont("helvetica", "normal"); // Fuente estándar que soporta acentos y caracteres comunes
    let y = 10;

    resultadosFiltrados.forEach((item, index) => {
      if(tipo === 'alertas'){
        // Escapar caracteres especiales si es necesario
        const texto = item.mensaje.replace(/[\u2018\u2019]/g, "'")
                                  .replace(/[\u201C\u201D]/g, '"');
        doc.text(`${index+1}. ${texto} - ${item.fecha_hora}`, 10, y);
        y += 10;
      } else if(tipo === 'sensor'){
        doc.text(`${index+1}. Temp: ${item.temperatura}°C, Humedad: ${item.humedad}% - ${item.fecha_hora}`, 10, y);
        y += 10;
      }
    });

    doc.save('resultados.pdf');
  };
} else {
  btnPDF.style.display = 'none';
}


  } catch(e){
    console.error(e);
    alert('Error al obtener datos');
  }
});

</script>
