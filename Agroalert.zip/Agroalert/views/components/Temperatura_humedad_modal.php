<!-- Modal -->
<div class="modal fade" id="tempHumModal" tabindex="-1" aria-labelledby="tempHumModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg">
      <div class="modal-header bg-gradient-success text-white">
        <h5 class="modal-title" id="tempHumModalLabel">
            <i class="bi bi-thermometer-half text-dark fs-3 me-2"></i>
  <span class="fw-bold fs-5" style="color: black;">Monitoreo Ambiental</span>
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body bg-dark p-4">
        <canvas id="sensorChart" height="300"></canvas>
      </div>
      <div class="modal-footer justify-content-center text-muted">
        <i class="bi bi-clock-history"></i> Datos actualizados cada 5 segundos
      </div>
    </div>
  </div>
</div>

<!-- Script integrado -->
<script>
let chart;
let intervaloGrafica;

async function obtenerDatos() {
  try {
    // Ruta de Getlecturas.php
    const res = await fetch('/web/Agroalert/views/getLecturas.php');
    const data = await res.json();
    return {
      labels: data.map(d => new Date(d.fecha_hora).toLocaleTimeString('es-MX', { hour12: false })),
      temperatura: data.map(d => parseFloat(d.temperatura)),
      humedad: data.map(d => parseFloat(d.humedad))
    };
  } catch (error) {
    console.error('Error al obtener datos:', error);
    return { labels: [], temperatura: [], humedad: [] };
  }
}

async function renderizarGrafica() {
  const datos = await obtenerDatos();
  const ctx = document.getElementById('sensorChart').getContext('2d');

  const gradientTemp = ctx.createLinearGradient(0, 0, 0, 300);
  gradientTemp.addColorStop(0, 'rgba(82, 34, 7, 0.6)');
  gradientTemp.addColorStop(1, 'rgba(255, 94, 0, 0.05)');

  const gradientHum = ctx.createLinearGradient(0, 0, 0, 300);
  gradientHum.addColorStop(0, 'rgba(0, 191, 255, 0.6)');
  gradientHum.addColorStop(1, 'rgba(0, 191, 255, 0.05)');

  chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: datos.labels,
      datasets: [
        {
          label: 'Temperatura (°C)',
          data: datos.temperatura,
          borderColor: '#ff5e00',
          backgroundColor: gradientTemp,
          borderWidth: 3,
          tension: 0.35,
          fill: true,
          yAxisID: 'y1',
          pointRadius: 5,
          pointBackgroundColor: '#ff5e00',
          pointBorderColor: '#fff',
          pointHoverRadius: 8,
          pointHoverBackgroundColor: '#ff8c42'
        },
        {
          label: 'Humedad (%)',
          data: datos.humedad,
          borderColor: '#00bfff',
          backgroundColor: gradientHum,
          borderWidth: 3,
          tension: 0.35,
          fill: true,
          yAxisID: 'y2',
          pointRadius: 5,
          borderDash: [6,4],
          pointBackgroundColor: '#00bfff',
          pointBorderColor: '#fff',
          pointHoverRadius: 8,
          pointHoverBackgroundColor: '#33ccff'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      scales: {
        y1: { position:'left', title:{ display:true, text:'Temperatura (°C)', color:'#ff5e00'}, ticks:{ color:'#ff8c42' } },
        y2: { position:'right', title:{ display:true, text:'Humedad (%)', color:'#00bfff'}, ticks:{ color:'#33ccff' }, grid:{ drawOnChartArea:false } },
        x: { title:{ display:true, text:'Hora de lectura', color:'#ccc'}, ticks:{ color:'#aaa', maxTicksLimit:10 }, grid:{ color:'rgba(255,255,255,0.05)' } }
      },
      plugins: { legend:{ position:'top', labels:{ color:'#fff', font:{ size:15, weight:'bold' } } } }
    }
  });
}

async function actualizarGrafica() {
  const datos = await obtenerDatos();
  if(chart){
    chart.data.labels = datos.labels;
    chart.data.datasets[0].data = datos.temperatura;
    chart.data.datasets[1].data = datos.humedad;
    chart.update('active');
  }
}

// Ejecutar al abrir el modal
const modal = document.getElementById('tempHumModal');
modal.addEventListener('shown.bs.modal', async () => {
  if(!chart) await renderizarGrafica();
  actualizarGrafica();
  intervaloGrafica = setInterval(actualizarGrafica, 5000);
});

// Detener intervalo al cerrar el modal
modal.addEventListener('hidden.bs.modal', () => {
  clearInterval(intervaloGrafica);
});
</script>

<script>
async function actualizarCards() {
  try {
    const datos = await obtenerDatos(); // Usamos la misma función que el modal
    if (datos.temperatura.length > 0 && datos.humedad.length > 0) {
      // Último valor
      const tempUltima = datos.temperatura[datos.temperatura.length - 1];
      const humUltima = datos.humedad[datos.humedad.length - 1];

      // Actualizamos el HTML
      document.getElementById('temp').textContent = `${tempUltima}°C`;
      document.getElementById('hum').textContent = `${humUltima}%`;
    }
  } catch (error) {
    console.error('Error actualizando cards:', error);
  }
}

// Llamar cada 5 segundos
actualizarCards(); // primera vez al cargar
setInterval(actualizarCards, 5000);
</script>
