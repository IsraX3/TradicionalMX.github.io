<div class="modal fade" id="modalActualizarUsuario" tabindex="-1" aria-labelledby="modalActualizarUsuarioLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow-lg">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="modalActualizarUsuarioLabel">
          <i class="bi bi-gear-fill me-2"></i>Actualizar mis datos
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>

      <div class="modal-body bg-light">
        <form id="formActualizarUsuario" class="p-3">
          <div class="row g-3">

            <!-- Nombre -->
            <div class="col-md-6">
              <label class="form-label fw-semibold text-success">
                <i class="bi bi-person me-1"></i>Nombre completo
              </label>
              <input type="text" class="form-control border-success" id="nombre" name="nombre" 
                     value="<?php echo htmlspecialchars($_SESSION['usuario_nombre'] ?? ''); ?>" required>
            </div>

            <!-- Correo -->
            <div class="col-md-6">
              <label class="form-label fw-semibold text-success">
                <i class="bi bi-envelope me-1"></i>Correo electrónico
              </label>
              <input type="email" class="form-control border-success" id="correo" name="correo" 
                     value="<?php echo htmlspecialchars($_SESSION['usuario'] ?? ''); ?>" required>
            </div>

            <!-- Contraseña -->
            <div class="col-md-6">
              <label class="form-label fw-semibold text-success">
                <i class="bi bi-lock me-1"></i>Nueva contraseña
              </label>
              <input type="password" class="form-control border-success" id="password" name="password" placeholder="••••••••">
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold text-success">
                <i class="bi bi-lock-fill me-1"></i>Confirmar contraseña
              </label>
              <input type="password" class="form-control border-success" id="confirmar" name="confirmar" placeholder="••••••••">
            </div>

          </div>

          <div class="mt-4 text-end">
            <button type="button" class="btn btn-outline-secondary me-2" data-bs-dismiss="modal">
              <i class="bi bi-x-circle me-1"></i>Cancelar
            </button>
            <button type="submit" class="btn btn-success">
              <i class="bi bi-check-circle me-1"></i>Guardar cambios
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>


<script>
document.getElementById('formActualizarUsuario').addEventListener('submit', async (e) => {
  e.preventDefault();

  const formData = new FormData(e.target);

  const response = await fetch('../controllers/ActualizarUserController.php', {
    method: 'POST',
    body: formData
  });

  const result = await response.json();

  if (result.status === 'success') {
    mostrarAlertaBootstrap('success', result.message);

    // Cierra el modal y actualiza el nombre mostrado en el navbar
    const modal = bootstrap.Modal.getInstance(document.getElementById('modalActualizarUsuario'));
    modal.hide();
    document.querySelector('strong').innerText = formData.get('nombre');
  } else {
    mostrarAlertaBootstrap('danger', result.message);
  }
});

// Función para mostrar alertas con Bootstrap
function mostrarAlertaBootstrap(tipo, mensaje) {
  const alertPlaceholder = document.getElementById('alertPlaceholder');
  alertPlaceholder.innerHTML = `
    <div class="alert alert-${tipo} alert-dismissible fade show" role="alert">
      ${mensaje}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
  `;
}
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
document.getElementById('formActualizarUsuario').addEventListener('submit', async (e) => {
  e.preventDefault();

  const formData = new FormData(e.target);

  // Mostrar animación de carga
  Swal.fire({
    title: 'Actualizando...',
    text: 'Por favor espera un momento',
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    }
  });

  try {
    const response = await fetch('../controllers/ActualizarUserController.php', {
      method: 'POST',
      body: formData
    });

    const result = await response.json();

    // Cerrar loader
    Swal.close();

    if (result.status === 'success') {
      // Mostrar éxito con estilo
      Swal.fire({
        icon: 'success',
        title: '¡Actualización exitosa!',
        text: result.message,
        showConfirmButton: false,
        timer: 2000,
        background: '#e9f9ee',
        iconColor: '#198754'
      });

      // Cierra el modal suavemente
      const modal = bootstrap.Modal.getInstance(document.getElementById('modalActualizarUsuario'));
      modal.hide();

      // Actualiza el nombre mostrado en el navbar
      document.querySelector('strong').innerText = formData.get('nombre');
    } else {
      // Mostrar error con estilo
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: result.message,
        confirmButtonColor: '#d33'
      });
    }

  } catch (error) {
    Swal.close();
    Swal.fire({
      icon: 'error',
      title: 'Error de conexión',
      text: 'No se pudo comunicar con el servidor.',
      confirmButtonColor: '#d33'
    });
  }
});
</script>

