
<?php
session_start();

// Si ya está logueado, lo mandamos al dashboard
if (isset($_SESSION['usuario'])) {
    header("Location: dashboard.php");
    exit;
}

// Si da clic al botón, solo lo mandamos al dashboard (sin validar aún)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['usuario'] = "admin@correo.com"; // Valor temporal
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Iniciar Sesión | AgroAlert</title>
  <link rel="stylesheet" href="../public/css/bootstrap.min.css">
  <style>
 body {
  margin: 0;
  height: 100vh;
  display: flex;
  justify-content: flex-end; /* formulario a la derecha en escritorio */
  align-items: center;
  font-family: 'Poppins', sans-serif;
  overflow: hidden;
  background: #000; /* fallback si el video no carga */
}

/* ===== VIDEO DE FONDO ===== */
#bg-video {
  position: fixed;
  right: 0;
  bottom: 0;
  min-width: 100%;
  min-height: 100%;
  width: auto;
  height: auto;
  z-index: -1;
  object-fit: cover;
  filter: brightness(0.7);
}

/* ===== FORMULARIO PRINCIPAL ===== */
.login-box {
  background: rgba(255, 255, 255, 0.2); /* fondo blanco semitransparente */
  backdrop-filter: blur(8px);           /* desenfoque detrás */
  border-radius: 20px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
  max-width: 400px;
  width: 90%;
  padding: 2rem;
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  animation: fadeIn 1.2s ease-in-out;
  margin: 5vh 5vw; /* margen general */
  height: auto;
}

/* ===== ANIMACIÓN ===== */
@keyframes fadeIn {
  from { opacity: 0; transform: translateX(50px); }
  to { opacity: 1; transform: translateX(0); }
}

/* ===== LOGO ===== */
.login-box img {
  width: 280px;
  max-width: 100%;
  display: block;
  margin: 0 auto 15px auto;
  object-fit: contain;
}

/* ===== TITULOS Y TEXTOS ===== */
.login-box h2 {
  margin-bottom: 10px;
  font-weight: 600;
  color: #38ef7d;
}

.login-box p {
  color: #ffffff;
  font-size: 14px;
  margin-bottom: 20px;
}

/* ===== CAMPOS DE ENTRADA ===== */
.login-box input {
  width: 100%;
  padding: 12px;
  margin: 10px 0;
  border: none;
  border-radius: 30px;
  outline: none;
  background: rgba(255, 255, 255, 0.4);
  color: #0a4d3c;
  font-weight: 500;
  font-size: 15px;
  transition: 0.3s;
}

.login-box input:focus {
  background: rgba(255, 255, 255, 0.8);
}

.login-box input::placeholder {
  color: rgba(0, 0, 0, 0.6);
}

/* ===== BOTONES ===== */
.login-box button {
  width: 100%;
  padding: 12px;
  margin-top: 15px;
  border: none;
  border-radius: 30px;
  background: linear-gradient(45deg, #38ef7d, #11998e);
  color: #fff;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

.login-box button:hover {
  transform: scale(1.05);
}

/* ===== TEXTO INFERIOR ===== */
.footer-text {
  margin-top: 20px;
  font-size: 13px;
  color: #ffffffd8;
}

/* ===== MODAL ===== */
.modal {
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background: rgba(0,0,0,0.6);
  display: none;
  justify-content: center;
  align-items: center;
  z-index: 10;
}

.modal-content {
  background: #fff;
  padding: 20px;
  border-radius: 12px;
  width: 90%;
  max-width: 400px;
  position: relative;
  box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

.modal-content h2 {
  margin-top: 0;
  color: #11998e;
}

.close {
  position: absolute;
  top: 10px; right: 15px;
  font-size: 20px;
  cursor: pointer;
  color: #444;
}

.modal-content input, .modal-content select {
  width: 100%;
  padding: 10px;
  margin: 8px 0;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.modal-content button {
  width: 100%;
  padding: 10px;
  background: #1565c0;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

.modal-content button:hover {
  background: #0d47a1;
}

.message {
  margin: 10px 0;
  font-size: 14px;
}

.error { color: red; }
.success { color: green; }

/* ===== RESPONSIVE ===== */
@media (max-width: 1024px) {
  body {
    justify-content: center; /* centrado en pantallas medianas */
  }
}

@media (max-width: 768px) {
  body {
    justify-content: center; /* formulario centrado en móviles */
    align-items: flex-start;
    overflow-y: auto;
  }

  .login-box {
    margin: 10vh auto;
    width: 90%;
    border-radius: 15px;
    box-shadow: none;
    padding: 1.5rem;
    height: auto;
  }

  #bg-video {
    object-position: center;
  }
}

@media (max-width: 480px) {
  .login-box img {
    width: 220px;
  }

  .login-box h2 {
    font-size: 20px;
  }

  .login-box input, .login-box button {
    font-size: 14px;
  }
}
  </style>



  </style>
</head>
<body>
    <video autoplay muted loop id="bg-video">
  <source src="../public/assets/video/fondoo.mp4" type="video/mp4">
  
</video>

<audio id="sound-error" src="../public/assets/sonidos/error.mp3" preload="auto"></audio>
<audio id="sound-success" src="../public/assets/sonidos/correct.mp3" preload="auto"></audio>

<!-- Formulario de Login -->
<form class="login-box" method="POST" action="../controllers/loginController.php">
  <img src="../public/assets/img/logo-oficial.png" alt="AgroAlert Logo">
  <h2>Bienvenido</h2>
  <p>Ingresa tus datos para acceder al panel</p>

  <!-- Mensajes dinámicos -->
  <?php if (!empty($_SESSION['login_error'])): ?>
    <p class="message error"><?php echo htmlspecialchars($_SESSION['login_error']); ?></p>
  <?php endif; ?>

  <?php if (!empty($_SESSION['login_success'])): ?>
    <p class="message success"><?php echo htmlspecialchars($_SESSION['login_success']); ?></p>
  <?php endif; ?>

  <input type="email" name="correo" placeholder="Correo electrónico" required>
  <input type="password" name="password" placeholder="Contraseña" required minlength="8">

  <!-- Este botón guarda una marca para permitir el sonido -->
  <button type="submit" onclick="localStorage.setItem('loginClicked', 'true')">
    Iniciar Sesión
  </button>

  <p>¿No tienes cuenta? <a href="#" onclick="openModal()">Regístrate aquí</a></p>

  <div class="footer-text">
    <p>© <script>document.write(new Date().getFullYear())</script> AgroAlert</p>
  </div>
</form>


<!-- Modal de Registro -->
<div id="modalRegistro" class="modal" style="display:none;">
  <div class="modal-content">
    <span class="close" onclick="closeModal()">&times;</span>
    <h2>Crear cuenta</h2>

    <?php if (!empty($_SESSION['register_error'])): ?>
      <p class="message error"><?php echo htmlspecialchars($_SESSION['register_error']); ?></p>
    <?php endif; ?>

    <?php if (!empty($_SESSION['register_success'])): ?>
      <p class="message success"><?php echo htmlspecialchars($_SESSION['register_success']); ?></p>
    <?php endif; ?>

    <form method="POST" action="../controllers/registerController.php">
      <input type="text" name="nombre" placeholder="Nombre completo" required>
      <input type="email" name="correo" placeholder="Correo electrónico" required>
      <input type="password" name="password" placeholder="Contraseña" required minlength="8">
      <select name="tipo_usuario">
        <option value="normal">Normal</option>
        <option value="root">Administrador</option>
      </select>
      <button type="submit" onclick="localStorage.setItem('registerClicked', 'true')">Registrar</button>
    </form>
  </div>
</div>


<script>
  function openModal() {
    document.getElementById('modalRegistro').style.display = 'flex';
  }

  function closeModal() {
    document.getElementById('modalRegistro').style.display = 'none';
  }

  window.onclick = function(event) {
    const modal = document.getElementById('modalRegistro');
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  }

  function playSound(type) {
    const audio = document.getElementById(type === 'error' ? 'sound-error' : 'sound-success');
    if (audio) audio.play();
  }

  //Reproduce sonido solo si hubo clic previo del usuario
  window.addEventListener('load', function() {
    const loginClicked = localStorage.getItem('loginClicked');
    const registerClicked = localStorage.getItem('registerClicked');

    if (loginClicked) {
      <?php if (!empty($_SESSION['login_error'])): ?>
        playSound('error');
      <?php elseif (!empty($_SESSION['login_success'])): ?>
        playSound('success');
      <?php endif; ?>
      localStorage.removeItem('loginClicked');
    }

    if (registerClicked) {
      <?php if (!empty($_SESSION['register_error'])): ?>
        playSound('error');
      <?php elseif (!empty($_SESSION['register_success'])): ?>
        playSound('success');
      <?php endif; ?>
      localStorage.removeItem('registerClicked');
    }
  });
</script>


</body>
</html>
