<?php
$host = "localhost";
$user = "agroalert";
$pass = "claveSegura";
$db   = "AgroAlert";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
